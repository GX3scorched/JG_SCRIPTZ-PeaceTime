-- Config for Peacetime JG_SCRIPTZ
Config = {}

-- Command used to toggle peacetime. You can change to '/peacetime', '/peace', etc
Config.Command = 'peacetime'

-- Who can toggle peacetime.
-- If UseESXPermissions = true, it will check xPlayer.getGroup() or xPlayer.getPermissions()
-- Otherwise it falls back to the permission string checked by ESX (addAce or server-side checks)
Config.UseESXPermissions = true
-- Allowed groups (when UseESXPermissions = true). Example groups: 'admin', 'superadmin', 'mod'
Config.AllowedGroups = { 'admin', 'superadmin' }

-- Message shown when peacetime toggles (will use ox_lib notify if available)
Config.EnableOxNotify = true

-- When true, the client will be made invincible during peacetime to prevent damage.
-- Note: This makes all players invincible (no health loss). It is a blunt but reliable prevention.
Config.MakePlayersInvincible = true

-- Controls to block while peacetime active (these are Control IDs)
-- Default list blocks primary/secondary attack, melee and throw weapon.
Config.BlockControls = {
    24, -- INPUT_ATTACK
    25, -- INPUT_AIM
    140, -- INPUT_MELEE_ATTACK_LIGHT
    141, -- INPUT_MELEE_ATTACK_HEAVY
    142, -- INPUT_MELEE_ATTACK_ALTERNATE
    257, -- INPUT_ATTACK2 (enter aim/fire on certain controllers)
    263, -- INPUT_MELEE_ATTACK1
    264, -- INPUT_MELEE_ATTACK2
    69,  -- INPUT_VEH_ATTACK
    70,  -- INPUT_VEH_ATTACK2
    22,  -- INPUT_JUMP (optional)
}

-- Optional: show a small periodic help text while peacetime is enabled
Config.ShowHelpText = true

-- Notification texts (simple; you can modify)
Config.Texts = {
    enabled = "Peacetime ENABLED — combat is blocked.",
    disabled = "Peacetime DISABLED — combat allowed.",
    no_perm = "You don't have permission to toggle peacetime.",
    already = "Peacetime is already %s."
}
