-- server.lua (ESX peacetime)
ESX = nil
local Peacetime = false

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- helper to check permission
local function isAllowed(xPlayer)
    if not xPlayer then return false end
    if Config.UseESXPermissions then
        local g = xPlayer.getGroup and xPlayer.getGroup() or nil
        if g then
            for _,allowed in pairs(Config.AllowedGroups) do
                if tostring(g):lower() == tostring(allowed):lower() then
                    return true
                end
            end
        end
        return false
    end
    return xPlayer.getPermissions and xPlayer.getPermissions()['admin'] -- fallback (rare)
end

RegisterCommand(Config.Command, function(source, args, raw)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        -- console or non-player
        Peacetime = not Peacetime
        print(('[peacetime] toggled by console -> %s'):format(tostring(Peacetime)))
        TriggerClientEvent('peacetime:setState', -1, Peacetime)
        return
    end

    if not isAllowed(xPlayer) then
        TriggerClientEvent('peacetime:notify', source, false, Config.Texts.no_perm)
        return
    end

    Peacetime = not Peacetime
    local text = Peacetime and Config.Texts.enabled or Config.Texts.disabled
    -- broadcast to all clients
    TriggerClientEvent('peacetime:setState', -1, Peacetime)
    -- notify toggler
    TriggerClientEvent('peacetime:notify', source, true, ('Peacetime toggled -> %s'):format(tostring(Peacetime)))
    print(('[peacetime] toggled by %s (%s) -> %s'):format(xPlayer.getIdentifier() or 'unknown', xPlayer.identifier or 'unknown', tostring(Peacetime)))
end, false)

-- Provide an export for other resources to query or set peacetime
exports('isPeacetime', function()
    return Peacetime
end)

exports('setPeacetime', function(state)
    Peacetime = not not state
    TriggerClientEvent('peacetime:setState', -1, Peacetime)
end)

-- On server start inform console of status
AddEventHandler('onResourceStart', function(name)
    if name == GetCurrentResourceName() then
        print(('[peacetime] resource started. initial state = %s'):format(tostring(Peacetime)))
    end
end)
