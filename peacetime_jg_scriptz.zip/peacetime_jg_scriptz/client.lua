-- client.lua (ESX peacetime)
local Peacetime = false
local ox = exports['ox_lib'] or nil

local function notify(source, success, text)
    if Config.EnableOxNotify and exports and exports.ox_lib and exports.ox_lib.notify then
        exports.ox_lib.notify({ type = success and 'success' or 'error', description = text })
        return
    end
    -- fallback
    TriggerEvent('chat:addMessage', { args = { '[Peacetime]', text } })
end

-- set invincible state for the local player
local function setInvincible(state)
    if not Config.MakePlayersInvincible then return end
    local ped = PlayerPedId()
    if DoesEntityExist(ped) then
        SetEntityInvincible(ped, state)
        SetPlayerInvincible(PlayerId(), state)
        if state then
            SetEntityHealth(ped, GetEntityMaxHealth(ped))
            ClearPedTasksImmediately(ped)
        end
    end
end

RegisterNetEvent('peacetime:setState', function(state)
    Peacetime = state and true or false
    setInvincible(Peacetime)
    if Peacetime then
        notify(nil, true, Config.Texts.enabled)
    else
        notify(nil, true, Config.Texts.disabled)
    end
end)

RegisterNetEvent('peacetime:notify', function(source, success, text)
    notify(source, success, text)
end)

-- continually block controls when peacetime is active
CreateThread(function()
    while true do
        Wait(0)
        if Peacetime then
            for _, ctl in ipairs(Config.BlockControls) do
                DisableControlAction(0, ctl, true)
            end

            -- additionally prevent weapon firing by clearing tasks if player tries
            if IsPedShooting(PlayerPedId()) or IsControlJustPressed(0, 24) then
                ClearPedTasksImmediately(PlayerPedId())
                notify(nil, false, 'Peacetime is active — combat blocked.')
            end

            if Config.ShowHelpText then
                SetTextComponentFormat('STRING')
                AddTextComponentString('Peacetime is active — combat blocked.')
                DisplayHelpTextFromStringLabel(0, 0, 1, -1)
            end
        else
            Wait(200) -- reduce CPU when not peacetime
        end
    end
end)

-- ensure invincibility is reapplied on spawn if peacetime is active
AddEventHandler('playerSpawned', function()
    Wait(1000)
    if Peacetime then setInvincible(true) end
end)

-- make resource export accessible client-side too
exports('isPeacetime', function()
    return Peacetime
end)
