fx_version 'cerulean'
game 'gta5'

author 'JG_SCRIPTZ'
description 'ESX Peacetime - prevents players from attacking during peacetime (ox_lib + ox_target compatible)'
version '1.0.0'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

-- optional: include README in resource root
file 'README.md'

dependencies {
  'ox_lib',
  'ox_target'
}
